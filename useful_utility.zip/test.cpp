﻿#include <iostream>
#include <queue>
#include <vector>
#include <cctype>
using namespace std;
 
int main() {
    std::cout << "hello" << std::endl;
}
